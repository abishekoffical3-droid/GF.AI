package com.abishek.priyaai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF141414)
private val Red = Color(0xFFFF2D3D)
private val Soft = Color(0xFFB9B9C2)

data class ChatMessage(val role: String, val text: String)

class PriyaViewModel : ViewModel() {
    var screen by mutableStateOf("home")
    var backendUrl by mutableStateOf("")
    var ownerName by mutableStateOf("Abishek Bhusal")
    var status by mutableStateOf("Ready for you")
    var messages by mutableStateOf(listOf(ChatMessage("assistant", "Namaste Abishek 👋 Ma PRIYA ho. Ma Nepali, English ra Hindi ma help garna sakchu.")))
    var loading by mutableStateOf(false)

    private val client = OkHttpClient.Builder().callTimeout(40, java.util.concurrent.TimeUnit.SECONDS).build()

    fun send(text: String) {
        if (text.isBlank() || loading) return
        messages = messages + ChatMessage("user", text)
        loading = true; status = "Thinking..."
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (backendUrl.isBlank()) throw Exception("Settings ma Backend URL set gara.")
                val history = JSONArray().apply { messages.takeLast(12).forEach { put(JSONObject().put("role", it.role).put("text", it.text)) } }
                val body = JSONObject().put("message", text).put("ownerName", ownerName).put("history", history).toString()
                val req = Request.Builder().url(backendUrl.trimEnd('/') + "/api/chat")
                    .post(body.toRequestBody("application/json".toMediaType())).build()
                client.newCall(req).execute().use { r ->
                    val raw = r.body?.string().orEmpty(); val json = JSONObject(raw)
                    if (!r.isSuccessful) throw Exception(json.optString("error", "Request failed"))
                    val answer = json.optString("text", "No response.")
                    withContext(Dispatchers.Main) { messages = messages + ChatMessage("assistant", answer); status = "Ready for you" }
                }
            } catch (e: Exception) { withContext(Dispatchers.Main) { messages = messages + ChatMessage("assistant", "⚠️ ${e.message ?: "Connection problem"}"); status = "Offline / check Settings" } }
            finally { withContext(Dispatchers.Main) { loading = false } }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PriyaApp() } }
}

@Composable fun PriyaApp(vm: PriyaViewModel = viewModel()) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, surface = Panel, background = Bg)) {
        Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
            when(vm.screen) { "chat" -> ChatScreen(vm); "settings" -> SettingsScreen(vm); else -> HomeScreen(vm) }
        }
    }
}

@Composable fun HomeScreen(vm: PriyaViewModel) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(0.96f, 1.05f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulse")
    val context = LocalContext.current
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { vm.screen="chat"; vm.send(it) }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if(ok) launchSpeech(context, speechLauncher) else vm.status="Microphone permission denied" }
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(36.dp))
        Box(Modifier.size(72.dp).scale(pulse).background(Red, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint=Color.White, modifier=Modifier.size(32.dp)) }
        Spacer(Modifier.height(22.dp)); Text("PRIYA", fontSize=38.sp, fontWeight=FontWeight.Bold); Text("Your personal AI companion", color=Soft)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(230.dp).scale(pulse).background(Color(0xFFB00008), CircleShape), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.Center) { Icon(Icons.Default.Mic, null, tint=Color.White, modifier=Modifier.size(70.dp)); Text(vm.status, color=Color.White, textAlign=TextAlign.Center, modifier=Modifier.padding(top=12.dp)) }
        }
        Spacer(Modifier.height(40.dp))
        Button(onClick={ if(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) launchSpeech(context,speechLauncher) else permission.launch(Manifest.permission.RECORD_AUDIO) }, shape=RoundedCornerShape(30.dp), modifier=Modifier.fillMaxWidth().height(58.dp)) { Icon(Icons.Default.GraphicEq,null); Spacer(Modifier.width(8.dp)); Text("TALK", fontSize=17.sp) }
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick={vm.screen="chat"}, modifier=Modifier.fillMaxWidth().height(56.dp), shape=RoundedCornerShape(30.dp)) { Icon(Icons.Default.Chat,null); Spacer(Modifier.width(8.dp)); Text("OPEN CHAT") }
        TextButton(onClick={vm.screen="settings"}) { Icon(Icons.Default.Settings,null); Spacer(Modifier.width(5.dp)); Text("SETTINGS") }
        Spacer(Modifier.height(22.dp))
    }
}

fun launchSpeech(context: Context, launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to PRIYA...") }
    launcher.launch(intent)
}

@Composable fun ChatScreen(vm: PriyaViewModel) {
    var input by remember { mutableStateOf("") }
    val context=LocalContext.current
    val tts = remember { TextToSpeech(context) { } }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={vm.screen="home"}){Icon(Icons.Default.ArrowBack,null)}; Column{Text("PRIYA",fontSize=24.sp,fontWeight=FontWeight.Bold); Text(vm.status,color=Soft,fontSize=12.sp)} }
        HorizontalDivider(color=Color(0xFF222222))
        LazyColumn(Modifier.weight(1f).padding(14.dp), reverseLayout=false) { items(vm.messages) { m -> val mine=m.role=="user"; Row(Modifier.fillMaxWidth().padding(vertical=6.dp), horizontalArrangement=if(mine) Arrangement.End else Arrangement.Start) { Surface(color=if(mine) Red else Panel, shape=RoundedCornerShape(20.dp)) { Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) { Text(m.text, modifier=Modifier.widthIn(max=280.dp)); if(!mine) IconButton(onClick={tts.language=Locale.getDefault(); tts.speak(m.text,TextToSpeech.QUEUE_FLUSH,null,"priya")}){Icon(Icons.Default.VolumeUp,null,modifier=Modifier.size(18.dp))} } } } }; if(vm.loading) item { Text("PRIYA is thinking...",color=Soft,modifier=Modifier.padding(10.dp)) } }
        Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(value=input,onValueChange={input=it},modifier=Modifier.weight(1f),placeholder={Text("Message PRIYA...")},shape=RoundedCornerShape(28.dp)); Spacer(Modifier.width(8.dp)); FloatingActionButton(onClick={vm.send(input); input=""}, containerColor=Red){Icon(Icons.Default.Send,null)} }
    }
}

@Composable fun SettingsScreen(vm: PriyaViewModel) {
    Column(Modifier.fillMaxSize().padding(22.dp)) { Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={vm.screen="home"}){Icon(Icons.Default.ArrowBack,null)}; Text("PRIYA Settings",fontSize=25.sp,fontWeight=FontWeight.Bold)}; Spacer(Modifier.height(22.dp)); Text("OWNER PROFILE",color=Red,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedTextField(value=vm.ownerName,onValueChange={vm.ownerName=it},label={Text("Owner name")},modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(20.dp)); Text("CONNECTION",color=Red,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedTextField(value=vm.backendUrl,onValueChange={vm.backendUrl=it},label={Text("Secure backend URL")},placeholder={Text("https://your-server.example")},modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); Text("Your Gemini API key stays on the backend — never inside the APK.",color=Soft,fontSize=13.sp); Spacer(Modifier.height(28.dp)); Surface(color=Panel,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("PRIYA Security",fontWeight=FontWeight.Bold); Text("• No API key in Android app\n• Backend proxy architecture\n• Limited chat history\n• Owner identity is profile-based, not biometric recognition\n• Review server CORS and rate limits before publishing",color=Soft,fontSize=13.sp)}} }
}
